import fetch from "node-fetch";

export default async function handler(req, res) {
  const {
    UTR_CLIENT_ID,
    UTR_CLIENT_SECRET,
    UTR_REDIRECT_URI,
    UTR_TOKEN_URL
  } = process.env;

  const code = req.query.code;
  const state = req.query.state;
  const cookie = req.headers.cookie || "";
  const savedState = cookie
    .split(";")
    .map(s => s.trim())
    .find(s => s.startsWith("utr_oauth_state="))
    ?.split("=")[1];

  if (!code) return res.status(400).send("Missing code.");
  if (!state || !savedState || state !== savedState) {
    return res.status(400).send("Invalid state.");
  }

  try {
    const tokenRes = await fetch(UTR_TOKEN_URL, {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: new URLSearchParams({
        grant_type: "authorization_code",
        code,
        redirect_uri: UTR_REDIRECT_URI,
        client_id: UTR_CLIENT_ID,
        client_secret: UTR_CLIENT_SECRET
      })
    });

    const tokenData = await tokenRes.json();
    if (!tokenRes.ok) {
      return res.status(500).send(`Token exchange failed: ${JSON.stringify(tokenData)}`);
    }

    const refreshToken = tokenData.refresh_token;
    const accessToken = tokenData.access_token;

    res.setHeader("Set-Cookie", [
      `utr_refresh_token=${refreshToken}; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=31536000`,
      `utr_access_token=${accessToken}; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=3600`
    ]);

    res.send("UTR Connected ✓ You can close this tab.");
  } catch (e) {
    res.status(500).send(`OAuth callback error: ${e.message}`);
  }
}
