export default async function handler(req, res) {
  const {
    UTR_CLIENT_ID,
    UTR_REDIRECT_URI,
    UTR_AUTH_URL
  } = process.env;

  if (!UTR_CLIENT_ID || !UTR_REDIRECT_URI || !UTR_AUTH_URL) {
    return res.status(500).send("Missing env vars for UTR OAuth.");
  }

  const state = "state-" + Math.random().toString(36).substring(2);

  const url =
    `${UTR_AUTH_URL}` +
    `?response_type=code` +
    `&client_id=${encodeURIComponent(UTR_CLIENT_ID)}` +
    `&redirect_uri=${encodeURIComponent(UTR_REDIRECT_URI)}` +
    `&state=${encodeURIComponent(state)}`;

  res.setHeader(
    "Set-Cookie",
    `utr_oauth_state=${state}; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=600`
  );

  res.writeHead(302, { Location: url });
  res.end();
}
