import fetch from "node-fetch";
import { rateLimit, logReq } from "./_utils.js";

export default async function handler(req, res) {
  if (!rateLimit(req, res, { windowMs: 60_000, max: 30 })) return;

  const {
    UTR_API_BASE,
    UTR_TOKEN_URL,
    UTR_CLIENT_ID,
    UTR_CLIENT_SECRET
  } = process.env;

  const playerEmail = req.query.playerEmail;

  logReq(req, { playerEmail });

  if (!playerEmail) {
    return res.status(400).json({ error: "playerEmail required" });
  }

  const cookie = req.headers.cookie || "";
  const refreshToken = cookie
    .split(";")
    .map(s => s.trim())
    .find(s => s.startsWith("utr_refresh_token="))
    ?.split("=")[1];

  if (!refreshToken) {
    return res.status(401).json({ error: "UTR not connected. Click Connect UTR first." });
  }

  try {
    const tokenRes = await fetch(UTR_TOKEN_URL, {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: new URLSearchParams({
        grant_type: "refresh_token",
        refresh_token: refreshToken,
        client_id: UTR_CLIENT_ID,
        client_secret: UTR_CLIENT_SECRET
      })
    });

    const tokenData = await tokenRes.json();
    if (!tokenRes.ok) throw new Error("Refresh token failed");

    const accessToken = tokenData.access_token;

    const playerRes = await fetch(
      `${UTR_API_BASE}/players?email=${encodeURIComponent(playerEmail)}`,
      { headers: { Authorization: `Bearer ${accessToken}` } }
    );
    const playerData = await playerRes.json();
    if (!playerRes.ok) throw new Error("Player lookup failed");

    const utrPlayerId = playerData?.items?.[0]?.id;
    if (!utrPlayerId) {
      return res.json({ utrCurrent: null, tournaments: [] });
    }

    const ratingRes = await fetch(
      `${UTR_API_BASE}/players/${utrPlayerId}/rating`,
      { headers: { Authorization: `Bearer ${accessToken}` } }
    );
    const ratingData = await ratingRes.json();

    const tourRes = await fetch(
      `${UTR_API_BASE}/players/${utrPlayerId}/tournaments`,
      { headers: { Authorization: `Bearer ${accessToken}` } }
    );
    const tourData = await tourRes.json();

    res.json({
      utrCurrent: ratingData?.singlesUtr ?? ratingData?.utr ?? null,
      tournaments: Array.isArray(tourData?.items) ? tourData.items : []
    });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
}
